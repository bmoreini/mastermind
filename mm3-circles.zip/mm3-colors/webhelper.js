window.onload = start;
 /* Initialize Globals */
var colors=["r","b","g","w","c","y"];
var turn=1, code=[], thisTurn=[], turnRecords=[], alertString="", newGame=true;

function start() {
    code=setup();
}

function setup() {
    var currentTurns = document.getElementById("gameTurns");
    var gB = document.getElementById("guessButton");
    currentTurns.innerHTML = "Creating secret code.......";
    code=setCode(colors); 
    currentTurns.innerHTML = "Secret code created. Let's play!";
    gB.innerHTML = "Submit Guess 1"; 
    return code;
}

function newGuess() {
    if (newGame==false) {
        document.location.reload();
    }
    else {
        var currentTurns = document.getElementById("gameTurns");
        var gB = document.getElementById("guessButton");
        var guess=[];
        for (i=0;i<4;i++) {
            g=document.getElementById(i);
            guess[i]=g.options[g.selectedIndex].value;
        }
        console.log("Turn "+turn+": "+guess);
        if (guess[0]=="q"){
            currentTurns.innerHTML = "Quitter!";
            gB.innerHTML = "Play again?";
            newGame=false;
        }
        else {
            currentTurns.innerHTML = main(turn,code,guess);
            turn++;
        }
    }
}


function main(turn, code, guess) {
    var gB = document.getElementById("guessButton");
    feedback=testGuess(code,guess); 
    thisTurn=addTurn(guess,feedback);
    turnRecords.push(thisTurn);
    if (feedback[3]=="b") {
        alertString="Charlie, you won in "+turn+" turns!";
        gB.innerHTML = "Play again?"; 
        newGame=false;
    }
    else {
        alertString=formatTurnRecords(turnRecords,alertString);
        gB.innerHTML = "Submit Guess "+turn; 
    }
    return alertString;
}